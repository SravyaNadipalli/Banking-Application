export interface Iaccount {
    accountType:string;
    pan:string;
    aadhar:string;
    mobilenum:string;
    userId:number;
    balance: number;
  
}
