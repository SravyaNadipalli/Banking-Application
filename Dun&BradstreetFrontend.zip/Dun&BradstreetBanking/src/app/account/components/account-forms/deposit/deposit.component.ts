import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ideposit } from 'src/app/account/models/ideposit';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  deposit1: Ideposit = {
    amount: 0
  }

  constructor(private accountService: AccountService, private router: Router) { }
 

  deposit() {

    console.log(this.deposit1);

    let accountId = JSON.parse(localStorage.getItem('accountDetails')||'').accountId;

    this.accountService.withdraw(accountId,this.deposit1).subscribe(

      (res) => {

        console.log(res);

        this.router.navigate(['/dashboard']);

      },

      (err) => {

        console.log(err);

      }

    );

  }

 

  ngOnInit(): void {

  }

 
}
