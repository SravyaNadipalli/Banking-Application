export interface ILoan {
  credittType: string;
  userId: number;
}
