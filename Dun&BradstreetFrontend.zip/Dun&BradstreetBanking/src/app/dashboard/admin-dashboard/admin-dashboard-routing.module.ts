import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApproveLoansComponent } from './components/forms/approve-loans/approve-loans.component';
import { CloseAccountComponent } from './components/forms/close-account/close-account.component';
import { AdminGuard } from 'src/app/shared/guards/admin.guard';

const routes: Routes = [
  {
    path: 'approve-loan',
    component: ApproveLoansComponent,
    canActivate: [AdminGuard],
  },
  {
    path: 'suspend-account',
    component: CloseAccountComponent,
    canActivate: [AdminGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AdminDashboardRoutingModule { }
