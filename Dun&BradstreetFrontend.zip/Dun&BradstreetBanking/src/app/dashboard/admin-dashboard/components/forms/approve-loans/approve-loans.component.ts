import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoanService } from 'src/app/loan/services/loan.service';


@Component({
  selector: 'app-approve-loans',
  templateUrl: './approve-loans.component.html',
  styleUrls: ['./approve-loans.component.css']
})
export class ApproveLoansComponent implements OnInit {
  LoanId: string = '';
  error: string = '';
  constructor(private loanService: LoanService, private router: Router) {}

  ngOnInit(): void {}
  approveLoan() {
    this.loanService.approveLoan(this.LoanId).subscribe(
      (res) => {
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        this.error = "couldn't approve";
        console.log(err);
      }
    );
  }

}
